<?php
class Booking
{
    private mysqli $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // Get all bookings dengan filter
    public function all(array $filters = [], int $page = 1, int $perPage = 10): array
    {
        $offset = ($page - 1) * $perPage;
        $where = [];
        $params = [];
        $types = "";

        // Filter by user (untuk user biasa)
        if (isset($filters['user_id'])) {
            $where[] = "b.user_id = ?";
            $params[] = $filters['user_id'];
            $types .= "i";
        }

        // Filter by status
        if (isset($filters['status'])) {
            $where[] = "b.status = ?";
            $params[] = $filters['status'];
            $types .= "s";
        }

        // Filter by room
        if (isset($filters['room_id'])) {
            $where[] = "b.room_id = ?";
            $params[] = $filters['room_id'];
            $types .= "i";
        }

        $whereClause = $where ? "WHERE " . implode(" AND ", $where) : "";

        $sql = "SELECT b.*, u.full_name as user_name, r.name as room_name, r.hourly_rate 
                FROM bookings b 
                JOIN users u ON b.user_id = u.id 
                JOIN rooms r ON b.room_id = r.id 
                $whereClause 
                ORDER BY b.booking_date DESC, b.start_time DESC 
                LIMIT ?, ?";
        
        $params[] = $offset;
        $params[] = $perPage;
        $types .= "ii";

        $stmt = $this->db->prepare($sql);
        if ($params) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Count bookings untuk pagination
    public function count(array $filters = []): int
    {
        $where = [];
        $params = [];
        $types = "";

        if (isset($filters['user_id'])) {
            $where[] = "user_id = ?";
            $params[] = $filters['user_id'];
            $types .= "i";
        }

        if (isset($filters['status'])) {
            $where[] = "status = ?";
            $params[] = $filters['status'];
            $types .= "s";
        }

        $whereClause = $where ? "WHERE " . implode(" AND ", $where) : "";

        $sql = "SELECT COUNT(*) as total FROM bookings $whereClause";
        $stmt = $this->db->prepare($sql);
        
        if ($params) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return (int)$result['total'];
    }

    // Get booking by ID
    public function find(int $id): ?array
    {
        $sql = "SELECT b.*, u.full_name as user_name, u.email as user_email, 
                       r.name as room_name, r.hourly_rate, r.capacity, r.location 
                FROM bookings b 
                JOIN users u ON b.user_id = u.id 
                JOIN rooms r ON b.room_id = r.id 
                WHERE b.id = ?";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result ?: null;
    }

    // Create new booking
    // CREATE new booking
public function create(array $data): int
{
    // Calculate total cost - FIX TIME FORMAT ISSUE
    try {
        $start = DateTime::createFromFormat('H:i', $data['start_time']);
        $end = DateTime::createFromFormat('H:i', $data['end_time']);
        
        // Validate time parsing
        if (!$start || !$end) {
            throw new Exception('Invalid time format');
        }
        
        $hours = ($end->getTimestamp() - $start->getTimestamp()) / 3600;
        
        // Ensure minimum 1 hour booking
        if ($hours < 1) {
            $hours = 1;
        }
        
        $totalCost = $hours * $data['hourly_rate'];
        
    } catch (Exception $e) {
        // Fallback calculation if time parsing fails
        $hours = 1; // Default 1 hour
        $totalCost = $hours * $data['hourly_rate'];
    }

    $stmt = $this->db->prepare("INSERT INTO bookings (user_id, room_id, purpose, booking_date, start_time, end_time, total_cost) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iissssd", $data['user_id'], $data['room_id'], $data['purpose'], $data['booking_date'], $data['start_time'], $data['end_time'], $totalCost);
    $stmt->execute();
    return $this->db->insert_id;
}
    // Update booking status (admin)
    public function updateStatus(int $id, string $status, string $adminNotes = ''): bool
    {
        $stmt = $this->db->prepare("UPDATE bookings SET status = ?, admin_notes = ? WHERE id = ?");
        $stmt->bind_param("ssi", $status, $adminNotes, $id);
        return $stmt->execute();
    }

    // Update booking (user)
    public function update(int $id, array $data): bool
    {
        // Recalculate total cost
        $start = DateTime::createFromFormat('H:i:s', $data['start_time']);
        $end = DateTime::createFromFormat('H:i:s', $data['end_time']);
        $hours = ($end->getTimestamp() - $start->getTimestamp()) / 3600;
        $totalCost = $hours * $data['hourly_rate'];

        $stmt = $this->db->prepare("UPDATE bookings SET purpose=?, booking_date=?, start_time=?, end_time=?, total_cost=? WHERE id=?");
        $stmt->bind_param("ssssdi", $data['purpose'], $data['booking_date'], $data['start_time'], $data['end_time'], $totalCost, $id);
        return $stmt->execute();
    }

    // Delete booking
    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM bookings WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }

    // Get bookings for calendar
    public function getCalendarEvents(string $month, string $year): array
    {
        $sql = "SELECT b.booking_date, b.start_time, b.end_time, r.name as room_name, 
                       u.full_name as user_name, b.status 
                FROM bookings b 
                JOIN rooms r ON b.room_id = r.id 
                JOIN users u ON b.user_id = u.id 
                WHERE MONTH(b.booking_date) = ? AND YEAR(b.booking_date) = ? 
                AND b.status IN ('pending', 'approved')
                ORDER BY b.booking_date, b.start_time";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ss", $month, $year);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}