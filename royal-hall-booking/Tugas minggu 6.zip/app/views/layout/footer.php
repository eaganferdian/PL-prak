</div>
        </main>

        <!-- Royal Footer -->
        <footer class="royal-footer">
            <div class="container">
                <div class="footer-content">
                    <div class="footer-section">
                        <h3>Royal Hall Booking</h3>
                        <p>Managing the kingdom's finest chambers since 1423</p>
                    </div>
                    <div class="footer-section">
                        <h4>Quick Links</h4>
                        <ul>
                            <li><a href="?c=dashboard">Dashboard</a></li>
                            <li><a href="?c=room">Royal Chambers</a></li>
                            <li><a href="?c=booking">My Bookings</a></li>
                        </ul>
                    </div>
                    <div class="footer-section">
                        <h4>Contact the Steward</h4>
                        <p>📧 steward@royalcastle.com</p>
                        <p>🏰 Main Castle - East Wing</p>
                    </div>
                </div>
                <div class="footer-bottom">
                    <p>&copy; <?= date('Y') ?> Royal Castle. All rights reserved by royal decree.</p>
                </div>
            </div>
        </footer>
    </div>
</body>
</html>